// app/api/settings/route.js — token CRUD with the v2 schema.
//
// Adds:
//   - messagePool (array) — rotation pool for content variance
//   - jitterPercent (0-75) — ±% randomized per send cycle
//   - mintContext (object) — captured browser context from /api/gettoken
//                            OR pasted from a real browser session via
//                            the "paste browser context" UI path
//
// Strip raw tokens on GET — UI gets `_hasToken` flag + masked prefix only.

import { NextResponse } from 'next/server';
import { isAuthorized } from '../../../lib/auth';
import { readState, writeState, normalizeTokenEntry } from '../../../lib/store';
import { BROWSER_USER_AGENT, buildSuperProperties } from '../../../lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: 'Please log in.' }, { status: 401 });
  }
  try {
    const state = await readState();
    const safe = {
      tokens: (state.tokens || []).map(t => {
        const norm = normalizeTokenEntry(t);
        return {
          ...norm,
          token: norm.token ? `${norm.token.slice(0, 10)}...` : '',
          _hasToken: !!norm.token,
        };
      }),
    };
    return NextResponse.json(safe, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return NextResponse.json({ error: error.message || 'Could not load settings.' }, { status: 500 });
  }
}

export async function PUT(request) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: 'Please log in.' }, { status: 401 });
  }
  try {
    const body  = await request.json();
    const state = await readState();

    if (body.action === 'add') {
      const {
        token, label, message, messagePool, channelIds,
        intervalSeconds, jitterPercent, mintContext,
      } = body;

      if (!token || !token.trim()) {
        return NextResponse.json({ error: 'Token is required.' }, { status: 400 });
      }
      // Either a single message or a non-empty messagePool must be present.
      const hasMessage = (typeof message === 'string' && message.trim()) ||
                          (Array.isArray(messagePool) && messagePool.filter(m => m.trim()).length);
      if (!hasMessage) {
        return NextResponse.json({ error: 'Either message or messagePool (non-empty) is required.' }, { status: 400 });
      }
      const ids = (channelIds || []).map(id => String(id).trim()).filter(id => /^\d{17,20}$/.test(id));
      if (!ids.length) {
        return NextResponse.json({ error: 'At least one valid channel ID is required.' }, { status: 400 });
      }

      // Build mintContext — if caller supplied one (from /api/gettoken),
      // persist it verbatim. Otherwise synthesize a bench-default context
      // so the send loop has SOMETHING to ship in headers.
      const ctx = mintContext && typeof mintContext === 'object' && mintContext.userAgent
        ? {
            userAgent:        mintContext.userAgent,
            superProperties:  mintContext.superProperties || buildSuperProperties(mintContext.userAgent),
            fingerprint:      mintContext.fingerprint || null,
            locale:           mintContext.locale    || 'en-US',
            timezone:         mintContext.timezone   || 'America/New_York',
            cookies:          mintContext.cookies && typeof mintContext.cookies === 'object' ? mintContext.cookies : {},
            mintedAt:         mintContext.mintedAt || new Date().toISOString(),
            mintedFromIp:     mintContext.mintedFromIp || 'pasted',
          }
        : {
            userAgent:        BROWSER_USER_AGENT,
            superProperties:  buildSuperProperties(BROWSER_USER_AGENT),
            fingerprint:      null,
            locale:           'en-US',
            timezone:         'America/New_York',
            cookies:          {},
            mintedAt:         new Date().toISOString(),
            mintedFromIp:     'synthesized',
          };

      const entry = normalizeTokenEntry({
        token: token.trim(),
        label: (label || '').trim() || `Token ${(state.tokens || []).length + 1}`,
        message: typeof message === 'string' ? message.trim() : '',
        messagePool: Array.isArray(messagePool) ? messagePool.map(m => String(m).trim()).filter(Boolean) : [],
        channelIds: ids,
        intervalSeconds: Math.max(30, Math.min(3600, Number(intervalSeconds) || 120)),
        jitterPercent:   Math.max(0,  Math.min(75,   Number(jitterPercent)   || 15)),
        mintContext: ctx,
        status: 'idle',
      });

      state.tokens = [...(state.tokens || []), entry];
      await writeState(state);
      return NextResponse.json({ ok: true, id: entry.id }, { headers: { 'Cache-Control': 'no-store' } });
    }

    if (body.action === 'update') {
      const { id, message, messagePool, channelIds, intervalSeconds, jitterPercent, label } = body;
      state.tokens = (state.tokens || []).map(t => {
        if (t.id !== id) return t;
        const merged = { ...t };
        if (label !== undefined)            merged.label        = label.trim();
        if (message !== undefined)          merged.message      = message.trim();
        if (Array.isArray(messagePool))    merged.messagePool  = messagePool.map(m => String(m).trim()).filter(Boolean);
        if (channelIds !== undefined) {
          const ids = channelIds.map(c => String(c).trim()).filter(c => /^\d{17,20}$/.test(c));
          if (ids.length) merged.channelIds = ids;
        }
        if (intervalSeconds !== undefined) merged.intervalSeconds = Math.max(30, Math.min(3600, Number(intervalSeconds) || 120));
        if (jitterPercent !== undefined)   merged.jitterPercent   = Math.max(0,  Math.min(75,   Number(jitterPercent)   || 0));
        return normalizeTokenEntry(merged);
      });
      await writeState(state);
      return NextResponse.json({ ok: true });
    }

    if (body.action === 'remove') {
      state.tokens = (state.tokens || []).filter(t => t.id !== body.id);
      await writeState(state);
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: 'Unknown action.' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: error.message || 'Could not save.' }, { status: 500 });
  }
}
