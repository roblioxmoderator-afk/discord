// app/api/cron/send/route.js — HTTP trigger for the send loop.
//
// In v3 (self-hosted), this is OPTIONAL — the in-process scheduler ticks
// every 60s automatically. This route still exists so you can:
//   - Manually trigger a tick from the dashboard
//   - Hook an external monitor (uptime robot, cron-job.org) if you want
//     belt-and-suspenders
//   - Run a one-off send immediately without waiting for the next interval
//
// Auth: `Authorization: Bearer <CRON_SECRET>` if CRON_SECRET is set.
// If CRON_SECRET is unset, the route is open — rely on network ACLs
// (don't expose the dashboard publicly without auth).

import { NextResponse } from 'next/server';
import { runSendTick } from '../../../../lib/sender.js';
import { schedulerStatus } from '../../../../lib/scheduler.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function GET(request) {
  // Auth check — only if CRON_SECRET is configured.
  const cronSecret = process.env.CRON_SECRET;
  if (cronSecret) {
    if (request.headers.get('authorization') !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
    }
  }

  const result = await runSendTick({
    authorization: request.headers.get('authorization') || '',
    skipAuth: !cronSecret,  // no secret configured → trust the caller
  });

  if (result.httpStatus === 401) {
    return NextResponse.json({ error: result.error }, { status: 401 });
  }
  if (result.httpStatus === 500) {
    return NextResponse.json({ error: result.error }, { status: 500 });
  }

  return NextResponse.json({
    ok: true,
    sent:    result.sent    || 0,
    errors:  result.errors  || 0,
    skipped: result.skipped || null,
    scheduler: schedulerStatus(),
  });
}

// POST is the same — let the dashboard hit it without worrying about GET
// caching rules.
export async function POST(request) {
  return GET(request);
}
