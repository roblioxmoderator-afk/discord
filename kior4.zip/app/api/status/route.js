// app/api/status/route.js — bench status endpoint for the dashboard.
//
// Returns scheduler running state + token counts. The dashboard polls
// this to display "scheduler: running" indicator and confirm the work
// continues even when the browser is closed.

import { NextResponse } from 'next/server';
import { isAuthorized } from '../../../lib/auth.js';
import { readState } from '../../../lib/store.js';
import { processManagersStatus } from '../../../lib/process-manager.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request) {
  // Status info is gated behind dashboard auth — don't expose scheduler
  // state to anonymous callers.
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: 'Please log in.' }, { status: 401 });
  }

  const state = await readState();
  const tokens   = state.tokens || [];
  const running  = tokens.filter(t => t.status === 'running').length;
  const idle     = tokens.filter(t => t.status === 'idle').length;
  const stopped  = tokens.filter(t => t.status === 'stopped').length;

  return NextResponse.json({
    scheduler: processManagersStatus(),
    tokens:    { total: tokens.length, running, idle, stopped },
    timestamp: new Date().toISOString(),
  }, { headers: { 'Cache-Control': 'no-store' } });
}
