// app/api/gettoken/mfa/route.js — TOTP MFA step for token minting.
//
// Caller posts { code, ticket, context } — context is the object returned
// by /api/gettoken on the password step. We reuse it verbatim so Discord
// sees the same browser session continuing, not a fresh request.

import { NextResponse } from 'next/server';
import { isAuthorized } from '../../../../lib/auth';
import { discordFetch } from '../../../../lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function POST(request) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: 'Please log in.' }, { status: 401 });
  }
  try {
    const { code, ticket, context } = await request.json();
    if (!code || !ticket) {
      return NextResponse.json({ error: 'Code and ticket required.' }, { status: 400 });
    }
    if (!context || typeof context !== 'object') {
      return NextResponse.json({ error: 'Browser context required.' }, { status: 400 });
    }

    const r = await discordFetch('https://discord.com/api/v10/auth/mfa/totp', {
      method: 'POST',
      ctx: context,
      body: { code: String(code).replace(/\s/g, ''), ticket },
    });
    const data = await r.json().catch(() => ({}));

    if (data.token) {
      return NextResponse.json({ token: data.token, context });
    }
    return NextResponse.json({ error: data.message || 'Invalid MFA code.' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: e.message || 'Request failed.' }, { status: 500 });
  }
}
