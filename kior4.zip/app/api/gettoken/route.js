// app/api/gettoken/route.js — mint a Discord user token from email + password,
// capture the browser context for reuse at send time.
//
// The biggest risk in the original v1 was minting tokens via API login from
// a datacenter IP without persisting the browser context — the send loop
// then used a different UA / super-props / no fingerprint / no cookies,
// which trips Discord's continuity checks on the first send.
//
// This version:
//   1. Uses the full Chrome-128 super-props blob (built in lib/http.js)
//   2. Fetches X-Fingerprint from /experiments before login
//   3. Persists every response cookie back to the returned context
//   4. Returns the context alongside the token so the dashboard can save
//      it with the token entry — the cron loop then reuses it
//
// Residual risk: this is still an API login from a datacenter IP. The
// realistic fix is to paste a token harvested from a real browser session.
// See README "Known risks" — the mint path is included for parity with v1,
// not because it's ban-safe.

import { NextResponse } from 'next/server';
import { isAuthorized } from '../../../lib/auth';
import { discordFetch, BROWSER_USER_AGENT, buildSuperProperties } from '../../../lib/http';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function POST(request) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: 'Please log in.' }, { status: 401 });
  }

  try {
    const { email, password, locale, timezone } = await request.json();
    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password required.' }, { status: 400 });
    }

    // Build the context we'll ship on every request, and reuse at send time.
    // Cookies start empty — they get populated as Discord Set-Cookie's us.
    const ctx = {
      userAgent:        BROWSER_USER_AGENT,
      superProperties:  buildSuperProperties(BROWSER_USER_AGENT),
      fingerprint:      null,
      locale:           locale    || 'en-US',
      timezone:         timezone || 'America/New_York',
      cookies:          {},
      mintedAt:         new Date().toISOString(),
      mintedFromIp:     request.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown',
    };

    // Step 1 — fetch X-Fingerprint from /experiments. Discord's risk engine
    // expects this to be present on every authenticated request after
    // login, and it has to match the one used at login.
    try {
      const fr = await discordFetch('https://discord.com/api/v10/experiments', { ctx });
      const fd = await fr.json().catch(() => ({}));
      ctx.fingerprint = fd?.fingerprint || null;
    } catch {
      // non-fatal — login can proceed without fingerprint, just with higher risk
    }

    // Step 2 — POST /auth/login. Cookies set here (locale, theme, _csuid, cf_*)
    // get auto-persisted into ctx.cookies by discordFetch.
    const r = await discordFetch('https://discord.com/api/v10/auth/login', {
      method: 'POST',
      ctx,
      body: {
        login:             email,
        password,
        undelete:          false,
        login_source:      null,
        gift_code_sku_id:  null,
      },
    });
    const data = await r.json().catch(() => ({}));

    if (data.token) {
      return NextResponse.json({
        token:  data.token,
        context: ctx,   // caller (dashboard) saves this with the token entry
      });
    }

    if (data.mfa) {
      // MFA flow — return the ticket and the captured context. The mfa
      // route reuses the same context (same UA, super-props, fingerprint,
      // cookies) so the TOTP verification looks like the same browser
      // session that just did the password login.
      return NextResponse.json({
        mfa:     true,
        ticket:  data.ticket,
        context: ctx,
      });
    }

    // Captcha — Discord requires solving it client-side in a real browser.
    // The mint-via-API path can't bypass it. Operator must paste a token
    // harvested from their own browser instead.
    if (data.captcha_key) {
      return NextResponse.json({
        error: 'Discord requires a CAPTCHA on this IP. Use the "paste token" path instead of minting via API.',
        code:  'CAPTCHA_REQUIRED',
      }, { status: 429 });
    }

    const msg =
      data.message ||
      data.errors?.login?._errors?.[0]?.message ||
      'Login failed. Check your credentials.';
    return NextResponse.json({ error: msg }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: e.message || 'Request failed.' }, { status: 500 });
  }
}
