# Kior v3 — self-hosted, in-process, no external services

Single Next.js process. Dashboard is the UI, Node process is the worker. SQLite for state. In-process `setInterval` for the scheduler. WebSocket gateway stays open in the main process. No Vercel, no cron-job.org, no GitHub Actions, no Upstash. `npm install && npm start` and you're done.

## How it works

```
+-----------------------+
|  your browser (UI)    |
|  localhost:3000       |
+-----------+-----------+
            |  HTTP (login, add token, start, stop)
            v
+-----------------------+        +----------------+
|  Node process         |  ----> |  SQLite file  |
|  (next start)         |        |  ./kior.db    |
|                       |        +----------------+
|  - Next.js server     |
|  - scheduler (60s)    |        +----------------+
|  - gateway keeper (5s)|  ----> |  Discord API  |
|  - gateway WS clients |        +----------------+
+-----------------------+
```

The browser is just a remote control. Once you click **Start**, the Node process owns the work — closing the browser, putting your laptop to sleep (if the host is something else), or killing the tab does nothing. The work continues.

## Run it

```bash
npm install              # installs next, react, ws, better-sqlite3
cp .env.example .env    # set ADMIN_PASSWORD + SESSION_SECRET (the only required vars)
npm run build           # one-time
npm start               # starts the dashboard at http://localhost:3000
```

Open `http://localhost:3000`, log in with `ADMIN_PASSWORD`, add a token, click Start. That's it. The Node process keeps running until you kill it or the machine shuts down.

## What was cut vs v2

| v2 | v3 |
|---|---|
| Upstash Redis for state | SQLite file (`./kior.db`) — zero external services |
| External cron (cron-job.org / GH Actions / EasyCron) calling `/api/cron/send` | In-process `setInterval` scheduler — started on boot via `instrumentation.js` |
| `npm run gateway` separate process | Merged into main Next.js process — `instrumentation.js` boots the gateway keeper on server start |
| Vercel + long-running host both supported | Self-hosted only. Vercel is no longer the recommended target. |

## What v3 keeps from v2

All the ban-resistance work carries over:
- Per-token mint context (UA, X-Super-Properties, X-Fingerprint, cookies) reused at send time
- Full Chrome-128 super-props blob on every request
- Warmup (`GET /users/@me` + `GET /users/@me/guilds` + `POST /channels/<id>/typing`) before first send
- WebSocket gateway presence — opens on `wss://gateway.discord.gg`, IDENTIFY, heartbeats, RESUME on reconnect
- Interval jitter (`±jitterPercent` per cycle)
- Content variance (message pool rotation)
- Cookie jar persisted across requests
- Optional TLS/JA3 impersonation via `curl-impersonate` or `cycletls`

## File map

```
kior4/
├── instrumentation.js         # Next.js boot hook — starts scheduler + gateway
├── lib/
│   ├── storage.js              # SQLite-backed state (replaces Upstash)
│   ├── store.js                # backwards-compat shim — re-exports storage + token-shape helpers
│   ├── http.js                 # cookie-aware fetch with per-token browser context
│   ├── impersonate.js          # curl-impersonate / cycletls dispatch (env-gated)
│   ├── gateway.js              # WebSocket gateway client (identify/heartbeat/resume)
│   ├── scheduler.js            # in-process setInterval tick loop (no external cron)
│   ├── process-manager.js      # singleton that boots scheduler on Next.js startup
│   ├── sender.js               # extracted send-loop body + gateway keeper
│   └── auth.js                 # admin session HMAC + cookie
├── app/
│   ├── api/
│   │   ├── status/route.js     # GET /api/status — scheduler + token counts (dashboard polls)
│   │   ├── gettoken/route.js
│   │   ├── gettoken/mfa/route.js
│   │   ├── cron/send/route.js  # optional manual trigger; scheduler ticks every 60s automatically
│   │   ├── settings/route.js
│   │   ├── campaign/{start,stop}/route.js
│   │   ├── login/route.js
│   │   └── logout/route.js
│   ├── page.jsx                # dashboard UI
│   ├── layout.jsx
│   └── globals.css
├── package.json
├── next.config.mjs
├── .env.example
└── README.md
```

## Known platform floors (cannot be closed by software)

1. **Host must stay on.** Closing the browser — fine. The Node process keeps running. But if the host machine sleeps, the OS suspends the process; if it's off, the work stops. For true 24/7 unattended, run on a always-on machine: a $5 VPS, a Raspberry Pi, a NUC, or a home server with power settings set to never sleep.
2. **Datacenter IP still scores.** A VPS on AWS/GCP is in Discord's bot feed. Residential IP (your home ISP line, a residential-IP VPS provider) is materially safer.
3. **API login from datacenter pre-flags the token.** Use the harvest-from-browser path instead — DevTools → Network → `discord.com/api` → `Authorization` header. That token is born warm.
4. **TLS/JA3 without impersonation.** Set `USE_IMPERSONATE=1` + install `curl-impersonate` or `cycletls`. Without this, Node's OpenSSL JA3 ships on every request — bot signal.
5. **Selfbot use is against Discord ToS §3.** No software-level fix exists. The sanctioned path is a real bot account via the Developer Portal with a bot token.

## Surviving restarts

State lives in `./kior.db` (SQLite). If the Node process crashes or the machine reboots:
- Tokens marked `running` stay `running` — the scheduler picks them up on next boot.
- Gateway WS clients reconnect and RESUME on the same session if Discord allows; otherwise re-IDENTIFY.
- Send lock is stale-pruned on boot — no deadlock waiting on a TTL.

For auto-restart on crash, wrap with `pm2` or `systemd`:

```bash
# pm2
pm2 start "npm start" --name kior
pm2 save
pm2 startup

# systemd — /etc/systemd/system/kior.service
[Unit]
Description=Kior selfbot
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/kior
ExecStart=/usr/bin/npm start
EnvironmentFile=/opt/kior/.env
Restart=always
RestartSec=5
User=kior

[Install]
WantedBy=multi-user.target
```

## Security posture

- `ADMIN_PASSWORD` + `SESSION_SECRET` (≥32 chars) required for login.
- Admin cookie: HttpOnly + SameSite=Lax + Secure in prod, HMAC-SHA256 of `SESSION_SECRET`, `timingSafeEqual` compared.
- `CRON_SECRET` optional — only needed if you expose `/api/cron/send` to external callers. Default: trusted dashboard-only.
- SQLite file at `./kior.db` — file perms are your ACL. Don't expose the project directory to other users.
- Plaintext tokens at rest — encrypt the disk (LUKS, FileVault, BitLocker) if the host is shared.
- No `NEXT_PUBLIC_` secret leakage.
