// instrumentation.js — Next.js boot hook.
//
// Runs once when the Node server starts (both `next dev` and
// `next start` — but NOT in the Edge runtime or during build). Used to
// start the in-process scheduler + gateway manager.
//
// Refs:
//   https://nextjs.org/docs/app/building-your-application/optimizing/instrumentation

export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;     // skip edge / build
  // Dynamic import so the module doesn't get pulled into the client bundle
  // by Next.js's static analysis.
  const { startProcessManagers } = await import('./lib/process-manager.js');
  startProcessManagers();
  console.log('[instrumentation] process managers started');
}
